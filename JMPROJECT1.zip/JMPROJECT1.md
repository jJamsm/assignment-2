### JAMES MWITI MUTEGI 
### SD18/79234/25
### MATH 944


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy as stats
import seaborn as sns
```


```python
df=pd.read_csv("customer_churn_dataset-training-master.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Tenure</th>
      <th>Usage Frequency</th>
      <th>Support Calls</th>
      <th>Payment Delay</th>
      <th>Subscription Type</th>
      <th>Contract Length</th>
      <th>Total Spend</th>
      <th>Last Interaction</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.0</td>
      <td>30.0</td>
      <td>Female</td>
      <td>39.0</td>
      <td>14.0</td>
      <td>5.0</td>
      <td>18.0</td>
      <td>Standard</td>
      <td>Annual</td>
      <td>932.00</td>
      <td>17.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3.0</td>
      <td>65.0</td>
      <td>Female</td>
      <td>49.0</td>
      <td>1.0</td>
      <td>10.0</td>
      <td>8.0</td>
      <td>Basic</td>
      <td>Monthly</td>
      <td>557.00</td>
      <td>6.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>55.0</td>
      <td>Female</td>
      <td>14.0</td>
      <td>4.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>Basic</td>
      <td>Quarterly</td>
      <td>185.00</td>
      <td>3.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>58.0</td>
      <td>Male</td>
      <td>38.0</td>
      <td>21.0</td>
      <td>7.0</td>
      <td>7.0</td>
      <td>Standard</td>
      <td>Monthly</td>
      <td>396.00</td>
      <td>29.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6.0</td>
      <td>23.0</td>
      <td>Male</td>
      <td>32.0</td>
      <td>20.0</td>
      <td>5.0</td>
      <td>8.0</td>
      <td>Basic</td>
      <td>Monthly</td>
      <td>617.00</td>
      <td>20.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>440828</th>
      <td>449995.0</td>
      <td>42.0</td>
      <td>Male</td>
      <td>54.0</td>
      <td>15.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>Premium</td>
      <td>Annual</td>
      <td>716.38</td>
      <td>8.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440829</th>
      <td>449996.0</td>
      <td>25.0</td>
      <td>Female</td>
      <td>8.0</td>
      <td>13.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>Premium</td>
      <td>Annual</td>
      <td>745.38</td>
      <td>2.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440830</th>
      <td>449997.0</td>
      <td>26.0</td>
      <td>Male</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>1.0</td>
      <td>5.0</td>
      <td>Standard</td>
      <td>Quarterly</td>
      <td>977.31</td>
      <td>9.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440831</th>
      <td>449998.0</td>
      <td>28.0</td>
      <td>Male</td>
      <td>55.0</td>
      <td>14.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>Standard</td>
      <td>Quarterly</td>
      <td>602.55</td>
      <td>2.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440832</th>
      <td>449999.0</td>
      <td>31.0</td>
      <td>Male</td>
      <td>48.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>14.0</td>
      <td>Premium</td>
      <td>Quarterly</td>
      <td>567.77</td>
      <td>21.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>440833 rows × 12 columns</p>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Tenure</th>
      <th>Usage Frequency</th>
      <th>Support Calls</th>
      <th>Payment Delay</th>
      <th>Total Spend</th>
      <th>Last Interaction</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
      <td>440832.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>225398.667955</td>
      <td>39.373153</td>
      <td>31.256336</td>
      <td>15.807494</td>
      <td>3.604437</td>
      <td>12.965722</td>
      <td>631.616223</td>
      <td>14.480868</td>
      <td>0.567107</td>
    </tr>
    <tr>
      <th>std</th>
      <td>129531.918550</td>
      <td>12.442369</td>
      <td>17.255727</td>
      <td>8.586242</td>
      <td>3.070218</td>
      <td>8.258063</td>
      <td>240.803001</td>
      <td>8.596208</td>
      <td>0.495477</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.000000</td>
      <td>18.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>100.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>113621.750000</td>
      <td>29.000000</td>
      <td>16.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>480.000000</td>
      <td>7.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>226125.500000</td>
      <td>39.000000</td>
      <td>32.000000</td>
      <td>16.000000</td>
      <td>3.000000</td>
      <td>12.000000</td>
      <td>661.000000</td>
      <td>14.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>337739.250000</td>
      <td>48.000000</td>
      <td>46.000000</td>
      <td>23.000000</td>
      <td>6.000000</td>
      <td>19.000000</td>
      <td>830.000000</td>
      <td>22.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>449999.000000</td>
      <td>65.000000</td>
      <td>60.000000</td>
      <td>30.000000</td>
      <td>10.000000</td>
      <td>30.000000</td>
      <td>1000.000000</td>
      <td>30.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(df.info())
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 440833 entries, 0 to 440832
    Data columns (total 12 columns):
     #   Column             Non-Null Count   Dtype  
    ---  ------             --------------   -----  
     0   CustomerID         440832 non-null  float64
     1   Age                440832 non-null  float64
     2   Gender             440832 non-null  object 
     3   Tenure             440832 non-null  float64
     4   Usage Frequency    440832 non-null  float64
     5   Support Calls      440832 non-null  float64
     6   Payment Delay      440832 non-null  float64
     7   Subscription Type  440832 non-null  object 
     8   Contract Length    440832 non-null  object 
     9   Total Spend        440832 non-null  float64
     10  Last Interaction   440832 non-null  float64
     11  Churn              440832 non-null  float64
    dtypes: float64(9), object(3)
    memory usage: 40.4+ MB
    None
    


```python
print(df.isnull().sum())
```

    CustomerID           1
    Age                  1
    Gender               1
    Tenure               1
    Usage Frequency      1
    Support Calls        1
    Payment Delay        1
    Subscription Type    1
    Contract Length      1
    Total Spend          1
    Last Interaction     1
    Churn                1
    dtype: int64
    


```python
df_clean = df.dropna()  # Forward fill
```


```python
data=df_clean.copy()
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Tenure</th>
      <th>Usage Frequency</th>
      <th>Support Calls</th>
      <th>Payment Delay</th>
      <th>Subscription Type</th>
      <th>Contract Length</th>
      <th>Total Spend</th>
      <th>Last Interaction</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.0</td>
      <td>30.0</td>
      <td>Female</td>
      <td>39.0</td>
      <td>14.0</td>
      <td>5.0</td>
      <td>18.0</td>
      <td>Standard</td>
      <td>Annual</td>
      <td>932.00</td>
      <td>17.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3.0</td>
      <td>65.0</td>
      <td>Female</td>
      <td>49.0</td>
      <td>1.0</td>
      <td>10.0</td>
      <td>8.0</td>
      <td>Basic</td>
      <td>Monthly</td>
      <td>557.00</td>
      <td>6.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>55.0</td>
      <td>Female</td>
      <td>14.0</td>
      <td>4.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>Basic</td>
      <td>Quarterly</td>
      <td>185.00</td>
      <td>3.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5.0</td>
      <td>58.0</td>
      <td>Male</td>
      <td>38.0</td>
      <td>21.0</td>
      <td>7.0</td>
      <td>7.0</td>
      <td>Standard</td>
      <td>Monthly</td>
      <td>396.00</td>
      <td>29.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6.0</td>
      <td>23.0</td>
      <td>Male</td>
      <td>32.0</td>
      <td>20.0</td>
      <td>5.0</td>
      <td>8.0</td>
      <td>Basic</td>
      <td>Monthly</td>
      <td>617.00</td>
      <td>20.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>440828</th>
      <td>449995.0</td>
      <td>42.0</td>
      <td>Male</td>
      <td>54.0</td>
      <td>15.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>Premium</td>
      <td>Annual</td>
      <td>716.38</td>
      <td>8.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440829</th>
      <td>449996.0</td>
      <td>25.0</td>
      <td>Female</td>
      <td>8.0</td>
      <td>13.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>Premium</td>
      <td>Annual</td>
      <td>745.38</td>
      <td>2.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440830</th>
      <td>449997.0</td>
      <td>26.0</td>
      <td>Male</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>1.0</td>
      <td>5.0</td>
      <td>Standard</td>
      <td>Quarterly</td>
      <td>977.31</td>
      <td>9.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440831</th>
      <td>449998.0</td>
      <td>28.0</td>
      <td>Male</td>
      <td>55.0</td>
      <td>14.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>Standard</td>
      <td>Quarterly</td>
      <td>602.55</td>
      <td>2.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>440832</th>
      <td>449999.0</td>
      <td>31.0</td>
      <td>Male</td>
      <td>48.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>14.0</td>
      <td>Premium</td>
      <td>Quarterly</td>
      <td>567.77</td>
      <td>21.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>440832 rows × 12 columns</p>
</div>




```python
for col in data.select_dtypes(include=['object']).columns:
    data[col] = data[col].astype('category') # to change categorical data into factors
```


```python
print(data.dtypes)
```

    CustomerID            float64
    Age                   float64
    Gender               category
    Tenure                float64
    Usage Frequency       float64
    Support Calls         float64
    Payment Delay         float64
    Subscription Type    category
    Contract Length      category
    Total Spend           float64
    Last Interaction      float64
    Churn                 float64
    dtype: object
    


```python
exclude_cols = ["CustomerID","Churn"]
numeric_cols = data.select_dtypes(include=[np.number]).columns
numeric_cols = [col for col in numeric_cols if col not in exclude_cols]
zero_var_cols = []

for col in numeric_cols:
    if data[col].var() == 0:
        zero_var_cols.append(col)
if zero_var_cols:
    data_1 = df.drop(columns=zero_var_cols)
    print(f"\nRemoved {len(zero_var_cols)} zero variance columns")
else:
    print("\nNo zero variance columns found!")
```

    
    No zero variance columns found!
    


```python
# visualisation 
churn_counts = data['Churn'].value_counts()
churn_rate = (churn_counts / churn_counts.sum()) * 100

# Create bar chart
plt.figure(figsize=(8, 6))
bars = plt.bar(churn_rate.index, churn_rate.values, color=['green', 'red'], alpha=0.7)

plt.xlabel('Churn Status', fontsize=12)
plt.ylabel('Percentage (%)', fontsize=12)
plt.title('Churn Rate Distribution', fontsize=14, fontweight='bold')
plt.xticks([0, 1], ['No Churn', 'Churn'])

# Add percentage labels on bars
for i, bar in enumerate(bars):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height,
             f'{height:.1f}%',
             ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    



```python
# Create subplots for all three categorical variables
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# List of categorical variables
cat_vars = ['Gender', 'Subscription Type', 'Contract Length']

for idx, var in enumerate(cat_vars):
    # Calculate churn rate by category
    churn_by_cat = data.groupby(var, observed=True)['Churn'].agg(['sum', 'count']) #only to shows the categories that actually exist in my data
    churn_by_cat['churn_rate'] = (churn_by_cat['sum'] / churn_by_cat['count']) * 100
    
    # Create bar chart
    bars = axes[idx].bar(churn_by_cat.index, churn_by_cat['churn_rate'], 
                         color='steelblue', alpha=0.7)
    axes[idx].set_xlabel(var, fontsize=11)
    axes[idx].set_ylabel('Churn Rate (%)', fontsize=11)
    axes[idx].set_title(f'Churn Rate by {var}', fontsize=12, fontweight='bold')
    axes[idx].tick_params(axis='x', rotation=45)
    
    # Add percentage labels on bars
    for bar in bars:
        height = bar.get_height()
        axes[idx].text(bar.get_x() + bar.get_width()/2., height,
                      f'{height:.1f}%',
                      ha='center', va='bottom', fontsize=10)

plt.tight_layout()
plt.show()

# Print detailed statistics
print("Churn Rate by Category:\n" + "="*50)
for var in cat_vars:
    print(f"\n{var}:")
    churn_stats = df.groupby(var, observed=True)['Churn'].agg(['sum', 'count'])
    churn_stats['churn_rate'] = (churn_stats['sum'] / churn_stats['count']) * 100
    churn_stats.columns = ['Churned', 'Total', 'Churn Rate (%)']
    print(churn_stats)
```


    
![png](output_12_0.png)
    


    Churn Rate by Category:
    ==================================================
    
    Gender:
             Churned   Total  Churn Rate (%)
    Gender                                  
    Female  127058.0  190580       66.669115
    Male    122941.0  250252       49.126880
    
    Subscription Type:
                       Churned   Total  Churn Rate (%)
    Subscription Type                                 
    Basic              83210.0  143026       58.178233
    Premium            83173.0  148678       55.941700
    Standard           83616.0  149128       56.069953
    
    Contract Length:
                     Churned   Total  Churn Rate (%)
    Contract Length                                 
    Annual           81646.0  177198       46.076141
    Monthly          87104.0   87104      100.000000
    Quarterly        81249.0  176530       46.025605
    


```python
# Create subplots for the 3 most important variables
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# List of key variables
key_vars = ['Tenure', 'Support Calls', 'Payment Delay']

for idx, var in enumerate(key_vars):
    # Separate data by churn status
    no_churn = data[data['Churn'] == 0][var]
    churn = data[data['Churn'] == 1][var]
    
    # Create box plot
    bp = axes[idx].boxplot([no_churn, churn], 
                            tick_labels=['No Churn', 'Churn'],
                            patch_artist=True,
                            widths=0.6)
    
    colors = ['lightgreen', 'lightcoral']  # Color the boxes
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    
    axes[idx].set_xlabel('Churn Status', fontsize=11) # Add labels and title
    axes[idx].set_ylabel(var, fontsize=11)
    axes[idx].set_title(f'{var} by Churn Status', fontsize=12, fontweight='bold')
    axes[idx].grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.show()

# Print statistical comparison
print("Statistical Comparison:\n" + "="*60)
for var in key_vars:
    print(f"\n{var}:")
    print(f"  No Churn - Mean: {data[data['Churn']==0][var].mean():.2f}, Median: {data[data['Churn']==0][var].median():.2f}")
    print(f"  Churn    - Mean: {data[data['Churn']==1][var].mean():.2f}, Median: {data[data['Churn']==1][var].median():.2f}")
    print(f"  Difference: {data[data['Churn']==1][var].mean() - data[data['Churn']==0][var].mean():.2f}")
```


    
![png](output_13_0.png)
    


    Statistical Comparison:
    ============================================================
    
    Tenure:
      No Churn - Mean: 32.28, Median: 33.00
      Churn    - Mean: 30.47, Median: 30.00
      Difference: -1.81
    
    Support Calls:
      No Churn - Mean: 1.59, Median: 1.00
      Churn    - Mean: 5.14, Median: 5.00
      Difference: 3.56
    
    Payment Delay:
      No Churn - Mean: 10.02, Median: 10.00
      Churn    - Mean: 15.22, Median: 15.00
      Difference: 5.20
    


```python
# data partitioning for marchine learning
# we already have the testing set do no need to do the partationing 
```


```python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
X = data.drop(["Churn","CustomerID"], axis=1)
y = data['Churn']
```


```python
print(f"Original class distribution:")
print(f"No Churn (0): {(y==0).sum()} ({(y==0).sum()/len(y)*100:.2f}%)")
print(f"Churn (1): {(y==1).sum()} ({(y==1).sum()/len(y)*100:.2f}%)")
```

    Original class distribution:
    No Churn (0): 190833 (43.29%)
    Churn (1): 249999 (56.71%)
    


```python
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.3, 
                                                    random_state=42, stratify=y)

print(f"\nTraining set size: {len(X_train)} ({len(X_train)/len(data)*100:.1f}%)")
print(f"Validation set size: {len(X_val)} ({len(X_val)/len(data)*100:.1f}%)")
print(f"Churn rate in training: {y_train.mean()*100:.2f}%")
print(f"Churn rate in validation: {y_val.mean()*100:.2f}%\n")

```

    
    Training set size: 308582 (70.0%)
    Validation set size: 132250 (30.0%)
    Churn rate in training: 56.71%
    Churn rate in validation: 56.71%
    
    


```python
X_train_processed = X_train.copy() # Make copies. this help in avoid modifying original data
X_val_processed = X_val.copy()
```


```python
categorical_cols = ['Gender', 'Subscription Type', 'Contract Length']
label_encoders = {}

for col in categorical_cols:
    le = LabelEncoder()
    X_train_processed[col] = le.fit_transform(X_train_processed[col])
    X_val_processed[col] = le.transform(X_val_processed[col])
    label_encoders[col] = le
    print(f"Encoded {col}: {list(le.classes_)}")

# 2b. Scale numeric variables
numeric_cols = ['Age', 'Tenure', 'Usage Frequency', 'Support Calls', 
                'Payment Delay', 'Total Spend', 'Last Interaction']

scaler = StandardScaler()
X_train_processed[numeric_cols] = scaler.fit_transform(X_train_processed[numeric_cols])
X_val_processed[numeric_cols] = scaler.transform(X_val_processed[numeric_cols])

print(f"\nScaled {len(numeric_cols)} numeric variables")
print("Data preparation complete!\n")
```

    Encoded Gender: ['Female', 'Male']
    Encoded Subscription Type: ['Basic', 'Premium', 'Standard']
    Encoded Contract Length: ['Annual', 'Monthly', 'Quarterly']
    
    Scaled 7 numeric variables
    Data preparation complete!
    
    


```python
from imblearn.over_sampling import SMOTE
smote = SMOTE(random_state=42)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train_processed, y_train)

print(f"Before SMOTE:")
print(f"  No Churn: {(y_train==0).sum()}, Churn: {(y_train==1).sum()}")
print(f"After SMOTE:")
print(f"  No Churn: {(y_train_balanced==0).sum()}, Churn: {(y_train_balanced==1).sum()}")
print(f"Training set increased from {len(y_train)} to {len(y_train_balanced)} samples\n")
```

    Before SMOTE:
      No Churn: 133583, Churn: 174999
    After SMOTE:
      No Churn: 174999, Churn: 174999
    Training set increased from 308582 to 349998 samples
    
    


```python
print(f"Features (X): {list(X_train_processed.columns)}") #to see the x and y variables that are in our LR model
print(f"Target (y): Churn")
print(f"Total features: {X_train_processed.shape[1]}\n")
```

    Features (X): ['Age', 'Gender', 'Tenure', 'Usage Frequency', 'Support Calls', 'Payment Delay', 'Subscription Type', 'Contract Length', 'Total Spend', 'Last Interaction']
    Target (y): Churn
    Total features: 10
    
    


```python
glm_model = LogisticRegression(random_state=42, max_iter=1000)
glm_model.fit(X_train_balanced, y_train_balanced)

print("Model training complete!")
print(f"Model coefficients shape: {glm_model.coef_.shape}")
```

    Model training complete!
    Model coefficients shape: (1, 10)
    


```python
feature_importance = pd.DataFrame({
    'Feature': X_train_processed.columns,
    'Coefficient': glm_model.coef_[0]
}).sort_values('Coefficient', key=abs, ascending=False)

print("\nFeature Importance (sorted by absolute coefficient):")
print(feature_importance)
print()
```

    
    Feature Importance (sorted by absolute coefficient):
                 Feature  Coefficient
    4      Support Calls     2.139152
    8        Total Spend    -1.343762
    1             Gender    -1.046602
    5      Payment Delay     0.853128
    9   Last Interaction     0.476550
    0                Age     0.415674
    2             Tenure    -0.124659
    3    Usage Frequency    -0.111953
    6  Subscription Type    -0.050599
    7    Contract Length    -0.004845
    
    


```python
# check for overfiting- # Use Stratified K-Fold to maintain class distribution
from sklearn.model_selection import StratifiedKFold, cross_val_score
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Perform cross-validation on balanced training data
cv_scores = cross_val_score(glm_model, X_train_balanced, y_train_balanced, 
                             cv=cv, scoring='accuracy')

print(f"Cross-Validation Accuracy Scores: {cv_scores}")
print(f"Mean CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
print(f"Min CV Accuracy: {cv_scores.min():.4f}")
print(f"Max CV Accuracy: {cv_scores.max():.4f}")

# Check for overfitting
train_score = glm_model.score(X_train_balanced, y_train_balanced)
val_score = glm_model.score(X_val_processed, y_val)

print(f"\nOverfitting Check:")
print(f"Training Accuracy: {train_score:.4f}")
print(f"Validation Accuracy: {val_score:.4f}")
print(f"Difference: {train_score - val_score:.4f}")

if train_score - val_score > 0.05:
    print("⚠️ Warning: Possible overfitting detected (>5% difference)")
else:
    print("✓ Model appears to generalize well")
print()
```

    Cross-Validation Accuracy Scores: [0.85681429 0.85895714 0.85615714 0.85609794 0.85916942]
    Mean CV Accuracy: 0.8574 (+/- 0.0027)
    Min CV Accuracy: 0.8561
    Max CV Accuracy: 0.8592
    
    Overfitting Check:
    Training Accuracy: 0.8574
    Validation Accuracy: 0.8528
    Difference: 0.0046
    ✓ Model appears to generalize well
    
    


```python
# evaluate the model performance 
# Make predictions
y_train_pred = glm_model.predict(X_train_balanced)
y_val_pred = glm_model.predict(X_val_processed)
y_val_pred_proba = glm_model.predict_proba(X_val_processed)[:, 1]

# 5a. Performance metrics
print("\nPERFORMANCE METRICS:")
print("-"*60)
print(f"Training Accuracy:   {accuracy_score(y_train_balanced, y_train_pred):.4f}")
print(f"Validation Accuracy: {accuracy_score(y_val, y_val_pred):.4f}")
print(f"Precision:           {precision_score(y_val, y_val_pred):.4f}")
print(f"Recall:              {recall_score(y_val, y_val_pred):.4f}")
print(f"F1-Score:            {f1_score(y_val, y_val_pred):.4f}")
print(f"ROC-AUC Score:       {roc_auc_score(y_val, y_val_pred_proba):.4f}")

```

    
    PERFORMANCE METRICS:
    ------------------------------------------------------------
    Training Accuracy:   0.8574
    Validation Accuracy: 0.8528
    Precision:           0.9026
    Recall:              0.8300
    F1-Score:            0.8648
    ROC-AUC Score:       0.9285
    


```python
# 5b. Classification Report
print("\nCLASSIFICATION REPORT:")
print("-"*60)
print(classification_report(y_val, y_val_pred, target_names=['No Churn', 'Churn']))

# 5c. Confusion Matrix
cm = confusion_matrix(y_val, y_val_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['No Churn', 'Churn'],
            yticklabels=['No Churn', 'Churn'])
plt.title('Confusion Matrix', fontsize=14, fontweight='bold')
plt.ylabel('Actual', fontsize=12)
plt.xlabel('Predicted', fontsize=12)
plt.tight_layout()
plt.show()
```

    
    CLASSIFICATION REPORT:
    ------------------------------------------------------------
                  precision    recall  f1-score   support
    
        No Churn       0.80      0.88      0.84     57250
           Churn       0.90      0.83      0.86     75000
    
        accuracy                           0.85    132250
       macro avg       0.85      0.86      0.85    132250
    weighted avg       0.86      0.85      0.85    132250
    
    


    
![png](output_27_1.png)
    



```python
## ROC curve 
fpr, tpr, thresholds = roc_curve(y_val, y_val_pred_proba)
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, 
         label=f'ROC curve (AUC = {roc_auc_score(y_val, y_val_pred_proba):.4f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Classifier')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('ROC Curve', fontsize=14, fontweight='bold')
plt.legend(loc="lower right")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()

print("\n" + "="*60)
print("MODEL PIPELINE COMPLETE!")
print("="*60)
print("\nSUMMARY:")
print(f"✓ Data split with stratification")
print(f"✓ SMOTE applied to balance training data")
print(f"✓ 5-Fold Cross-Validation completed")
print(f"✓ Overfitting check performed")
print(f"✓ Model evaluated on validation set")
```


    
![png](output_28_0.png)
    


    
    ============================================================
    MODEL PIPELINE COMPLETE!
    ============================================================
    
    SUMMARY:
    ✓ Data split with stratification
    ✓ SMOTE applied to balance training data
    ✓ 5-Fold Cross-Validation completed
    ✓ Overfitting check performed
    ✓ Model evaluated on validation set
    


```python

```
